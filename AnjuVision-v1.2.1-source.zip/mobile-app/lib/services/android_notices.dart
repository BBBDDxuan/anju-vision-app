import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

class AndroidNotificationStatus {
  const AndroidNotificationStatus({
    required this.permissionRequired,
    required this.permissionGranted,
    required this.appEnabled,
    required this.channelEnabled,
  });
  final bool permissionRequired, permissionGranted, appEnabled, channelEnabled;
  bool get enabled => permissionGranted && appEnabled && channelEnabled;

  factory AndroidNotificationStatus.fromMap(Map<Object?, Object?> data) =>
      AndroidNotificationStatus(
        permissionRequired: data['permission_required'] == true,
        permissionGranted: data['permission_granted'] == true,
        appEnabled: data['app_enabled'] == true,
        channelEnabled: data['channel_enabled'] == true,
      );
}

/// App owns the single native click handler; settings only query this bridge.
/// No credentials, camera frames or external deep links are sent to Android.
class AndroidNotices {
  static const channelId = 'elder_safety_alerts_v1';
  static const _channel = MethodChannel('elder_safety/notifications');
  static AndroidNotices? _owner;
  Future<void>? _initializing;
  bool _disposed = false;

  static bool get supported =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  Future<void> initialize(void Function(String) onOpen) {
    if (!supported || _disposed) return Future.value();
    if (_owner != null && _owner != this) {
      return Future.error(
        StateError('Android notification handler already owned'),
      );
    }
    return _initializing ??= _initialize(onOpen);
  }

  Future<void> _initialize(void Function(String) onOpen) async {
    _owner = this;
    _channel.setMethodCallHandler((call) async {
      if (!_disposed &&
          call.method == 'openEvent' &&
          call.arguments is String) {
        onOpen(call.arguments as String);
      }
    });
    try {
      await _channel.invokeMethod<void>('initialize');
      final initial = await _channel.invokeMethod<String>('initialEvent');
      if (!_disposed && initial != null) onOpen(initial);
    } catch (_) {
      if (_owner == this) {
        _channel.setMethodCallHandler(null);
        _owner = null;
      }
      rethrow;
    }
  }

  Future<AndroidNotificationStatus?> status() async {
    if (!supported) return null;
    final data = await _channel.invokeMapMethod<Object?, Object?>('status');
    if (data == null) throw StateError('Android 未返回通知状态');
    return AndroidNotificationStatus.fromMap(data);
  }

  Future<AndroidNotificationStatus?> requestPermission() async {
    if (!supported) return null;
    final data = await _channel.invokeMapMethod<Object?, Object?>(
      'requestPermission',
    );
    if (data == null) throw StateError('Android 未返回通知权限状态');
    return AndroidNotificationStatus.fromMap(data);
  }

  Future<void> openAppSettings() async {
    if (supported) await _channel.invokeMethod<void>('openAppSettings');
  }

  Future<void> openNotificationSettings() async {
    if (supported)
      await _channel.invokeMethod<void>('openNotificationSettings');
  }

  Future<void> openChannelSettings() async {
    if (supported) await _channel.invokeMethod<void>('openChannelSettings');
  }

  Future<void> show(String eventId) async {
    if (supported && !_disposed) {
      await _channel.invokeMethod<void>('show', {'event_id': eventId});
    }
  }

  Future<void> clear() async {
    if (supported) await _channel.invokeMethod<void>('clear');
  }

  Future<void> dispose() async {
    _disposed = true;
    if (_owner == this) {
      _channel.setMethodCallHandler(null);
      _owner = null;
    }
  }
}
