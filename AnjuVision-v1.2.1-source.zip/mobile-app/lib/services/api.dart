import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../models/models.dart';

class ApiException implements Exception {
  const ApiException(this.message, {this.statusCode});
  final String message;
  final int? statusCode;
  @override
  String toString() => message;
}

abstract interface class SafetyRepository {
  Future<bool> health();
  Future<List<SafetyDevice>> devices();
  Future<List<SafetyEvent>> events();
  Future<SafetyEvent> event(String id);
  Future<Uint8List> evidence(String id);
  Future<void> acknowledge(String id);
  Future<void> resolve(String id);
  Future<FamilyPreferences> preferences();
  Future<void> savePreferences(FamilyPreferences preferences);
  Future<String> registerPush(String token, String platform, String contactId);
  Future<void> deletePush(String id);
  void close();
}

class HttpSafetyRepository implements SafetyRepository {
  HttpSafetyRepository({
    required String baseUrl,
    required this.bearerToken,
    http.Client? client,
    this.timeout = const Duration(seconds: 15),
  }) : baseUrl = baseUrl.replaceAll(RegExp(r'/+$'), ''),
       _client = client ?? http.Client();
  final String baseUrl;
  final String bearerToken;
  final http.Client _client;
  final Duration timeout;

  Future<http.Response> _request(
    String method,
    String path, {
    Object? body,
    bool authenticated = true,
    bool image = false,
  }) async {
    final request = http.Request(method, Uri.parse('$baseUrl$path'));
    request.followRedirects = false;
    request.headers['Accept'] = image ? 'image/*' : 'application/json';
    if (authenticated) request.headers['Authorization'] = 'Bearer $bearerToken';
    if (body != null) {
      request.headers['Content-Type'] = 'application/json';
      request.body = jsonEncode(body);
    }
    try {
      final response = await (() async => http.Response.fromStream(
        await _client.send(request),
      ))().timeout(timeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        final message = switch (response.statusCode) {
          401 => '认证失败，请在设置中检查用户 token',
          403 => '该用户无权访问此资源',
          404 => '资源不存在或已被删除',
          409 => '事件状态已变化，请刷新后重试',
          410 => '证据已过期，无法读取截图',
          422 => '字段不符合后端要求，请检查输入范围',
          _ => '后端请求失败（HTTP ${response.statusCode}）',
        };
        // Do not echo a response body which might contain credentials.
        throw ApiException(message, statusCode: response.statusCode);
      }
      return response;
    } on TimeoutException {
      throw const ApiException('连接超时，请检查网络与后端 URL');
    } on http.ClientException {
      throw const ApiException('无法连接后端，请检查网络、URL 和平台网络权限');
    }
  }

  dynamic _json(http.Response response) {
    try {
      return jsonDecode(utf8.decode(response.bodyBytes));
    } on FormatException {
      throw const ApiException('后端返回了无效 JSON');
    }
  }

  Future<List<dynamic>> _list(String path) async {
    final value = _json(await _request('GET', '/api/v1$path'));
    if (value is! List) throw const ApiException('后端应返回列表数组');
    return value;
  }

  Map<String, dynamic> _object(dynamic value) {
    if (value is! Map) throw const ApiException('后端应返回 JSON 对象');
    return Map<String, dynamic>.from(value);
  }

  String _id(String id) => Uri.encodeComponent(id);

  @override
  Future<bool> health() async =>
      (await _request('GET', '/health', authenticated: false)).statusCode < 300;
  @override
  Future<List<SafetyDevice>> devices() async => (await _list(
    '/devices',
  )).map((v) => SafetyDevice.fromJson(_object(v))).toList();
  @override
  Future<List<SafetyEvent>> events() async => (await _list(
    '/events',
  )).map((v) => SafetyEvent.fromJson(_object(v))).toList();
  @override
  Future<SafetyEvent> event(String id) async => SafetyEvent.fromJson(
    _object(_json(await _request('GET', '/api/v1/events/${_id(id)}'))),
  );
  @override
  Future<Uint8List> evidence(String id) async {
    final response = await _request(
      'GET',
      '/api/v1/evidence/${_id(id)}',
      image: true,
    );
    final type = response.headers['content-type']?.toLowerCase() ?? '';
    if (!type.startsWith('image/')) throw const ApiException('证据响应不是图片');
    return response.bodyBytes;
  }

  @override
  Future<void> acknowledge(String id) async {
    await _request('POST', '/api/v1/events/${_id(id)}/ack');
  }

  @override
  Future<void> resolve(String id) async {
    await _request('POST', '/api/v1/events/${_id(id)}/resolve');
  }

  @override
  Future<FamilyPreferences> preferences() async => FamilyPreferences.fromJson(
    _object(_json(await _request('GET', '/api/v1/preferences'))),
  );
  @override
  Future<void> savePreferences(FamilyPreferences preferences) async {
    await _request('PUT', '/api/v1/preferences', body: preferences.toJson());
  }

  @override
  Future<String> registerPush(
    String token,
    String platform,
    String contactId,
  ) async {
    final json = _object(
      _json(
        await _request(
          'POST',
          '/api/v1/push-tokens',
          body: {'token': token, 'platform': platform, 'contact_id': contactId},
        ),
      ),
    );
    final id = field(json, 'token_id');
    if (id.isEmpty) throw const ApiException('推送注册未返回 token_id');
    return id;
  }

  @override
  Future<void> deletePush(String id) async {
    try {
      await _request('DELETE', '/api/v1/push-tokens/${_id(id)}');
    } on ApiException catch (error) {
      if (error.statusCode != 404) rethrow;
    }
  }

  @override
  void close() => _client.close();
}
