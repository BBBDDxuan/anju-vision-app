# All toolchains and caches remain on G:. S: aliases this source only.
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../../..'))
. (Join-Path $workspace 'elder-safety/mobile-app/tool/android-env.ps1')
$physical = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$target = [Text.StringBuilder]::new(32768)
$length = [ElderSafetyBuildDrive]::QueryDosDevice('S:', $target, $target.Capacity)
if ($length -eq 0) {
    & subst.exe S: $physical
    if ($LASTEXITCODE -ne 0) { throw 'Cannot create source alias S:.' }
    [void]$target.Clear()
    $length = [ElderSafetyBuildDrive]::QueryDosDevice('S:', $target, $target.Capacity)
}
$expected = '\??\' + $physical.TrimEnd('\')
if ($length -eq 0 -or -not $target.ToString().TrimEnd([char]0).Equals($expected, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'S: is already in use. Existing mapping was not changed.'
}
$env:ELDER_SAFETY_BUILD_ROOT = 'S:\'
Set-Location S:\
