﻿[CmdletBinding()]
param([switch]$WithFirebase, [switch]$SkipChecks, [switch]$VerboseBuild)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'android-env.ps1')
$mobileRoot = $env:ELDER_SAFETY_BUILD_ROOT
$flutterExe = Join-Path $env:FLUTTER_ROOT 'bin/flutter.bat'
if (-not (Test-Path -LiteralPath $flutterExe)) { throw 'Flutter SDK is not installed. See the Android build guide.' }
if (-not (Test-Path -LiteralPath (Join-Path $mobileRoot 'android'))) { throw 'Generate the Android platform first with scaffold_platforms.ps1.' }
$firebaseValue = 'false'
if ($WithFirebase) {
    if (-not (Test-Path -LiteralPath (Join-Path $mobileRoot 'android/app/google-services.json'))) {
        throw 'Firebase client configuration is missing; no push build was started.'
    }
    $gradleSettings = Get-Content -LiteralPath (Join-Path $mobileRoot 'android/settings.gradle.kts') -Raw
    if (-not $gradleSettings.Contains('com.google.gms.google-services')) {
        throw 'Google Services Gradle integration is not configured yet. Finish Firebase project setup first.'
    }
    $firebaseValue = 'true'
}
$logRoot = Join-Path $PSScriptRoot 'logs'
[void][IO.Directory]::CreateDirectory($logRoot)
$statusFile = Join-Path $logRoot 'apk-build-status.json'
function Write-BuildStatus([string]$state, [string]$stage, [string]$artifact = '') {
    $status = @{ state = $state; stage = $stage; updated_at = (Get-Date).ToString('o'); apk = $artifact;
        firebase_enabled = [bool]$WithFirebase; real_phone_tested = $false }
    [IO.File]::WriteAllText($statusFile, ($status | ConvertTo-Json))
}
Write-BuildStatus 'running' 'verification'
Push-Location -LiteralPath $mobileRoot
try {
    if (-not $SkipChecks) {
        & (Join-Path $PSScriptRoot 'verify.ps1') -FlutterPath $flutterExe
        if ($LASTEXITCODE -ne 0) { throw 'Mobile verification failed.' }
    }
    Write-BuildStatus 'running' 'gradle_build'
    $buildArgs = @('build', 'apk', '--debug', '--no-pub', '--target-platform', 'android-arm64', "--dart-define=USE_FIREBASE=$firebaseValue")
    if ($VerboseBuild) { $buildArgs += '--verbose' }
    & $flutterExe @buildArgs
    if ($LASTEXITCODE -ne 0) { throw 'Android APK build failed. No successful APK is claimed.' }
    $apk = Join-Path $mobileRoot 'build/app/outputs/flutter-apk/app-debug.apk'
    if (-not (Test-Path -LiteralPath $apk)) { throw 'Expected build artifact was not produced.' }
    Write-BuildStatus 'running' 'artifact_verification'
    $signatureLog = Join-Path $logRoot 'apk-signature.log'
    & (Join-Path $env:ANDROID_HOME 'build-tools/36.0.0/apksigner.bat') verify --verbose --print-certs $apk *> $signatureLog
    if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed.' }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [IO.Compression.ZipFile]::OpenRead($apk)
    try {
        if (-not $archive.GetEntry('AndroidManifest.xml') -or -not $archive.GetEntry('classes.dex') -or
            -not $archive.GetEntry('lib/arm64-v8a/libflutter.so')) {
            throw 'APK is missing required Android/ARM64 payloads.'
        }
    } finally { $archive.Dispose() }
    & (Join-Path $env:ANDROID_HOME 'build-tools/36.0.0/aapt2.exe') dump badging $apk *> (Join-Path $logRoot 'apk-badging.log')
    if ($LASTEXITCODE -ne 0) { throw 'APK manifest verification failed.' }
    $physicalMobileRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $destinationRoot = [IO.Path]::GetFullPath((Join-Path $physicalMobileRoot '../deliverables/android'))
    [void][IO.Directory]::CreateDirectory($destinationRoot)
    $suffix = if ($WithFirebase) { 'fcm-test' } else { 'test' }
    $destination = Join-Path $destinationRoot "AnjuVision-v1.2.0-$suffix-arm64.apk"
    Copy-Item -LiteralPath $apk -Destination $destination -Force
    $digest = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant()
    [IO.File]::WriteAllText("$destination.sha256", "$digest  $([IO.Path]::GetFileName($destination))`n")
    Write-BuildStatus 'succeeded' 'complete' $destination
    Write-Host "APK: $destination"
    Write-Host "SHA256: $digest"
    Write-Host 'Internal debug build. Installation and notification delivery still require real-phone verification.'
} catch {
    Write-BuildStatus 'failed' 'see_android_apk_build_log'
    throw
} finally { Pop-Location }
